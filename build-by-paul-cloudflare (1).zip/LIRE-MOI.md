# Mettre Build By Paul en ligne — Cloudflare Pages

| Adresse | Page | Pour qui |
|---|---|---|
| `ton-site.pages.dev` | **L'espace bilans** | Tes clients et toi |
| `ton-site.pages.dev/methode` | La méthode + candidature | Public — ton lien de bio |

15 minutes, gratuit, sans carte bancaire.

---

## Pourquoi Cloudflare et pas Netlify

Netlify n'installe pas les dépendances quand on dépose un dossier à la main : les fonctions
qui enregistrent les bilans et les candidatures ne démarrent pas. Cloudflare fait tourner
les siennes directement, sans installation. C'est la seule différence, mais elle est décisive.

---

## Étape 1 — Mettre en ligne

1. Compte gratuit sur **dash.cloudflare.com**
2. **Workers & Pages** → **Create** → onglet **Pages** → **Upload assets**
3. Nom du projet : `buildbypaul`
4. Glisse **le contenu de ce dossier** : `index.html`, `methode/` et `functions/` à la racine
5. **Deploy**

---

## Étape 2 — Activer l'enregistrement

1. **Workers & Pages** → **KV** → **Create namespace** → nomme-le `buildbypaul-data`
2. Ton projet → **Settings** → **Bindings** → **Add** → **KV namespace**
   - Variable name : **`BBP`** (exactement, en majuscules)
   - KV namespace : `buildbypaul-data`
3. **Save**

---

## Étape 3 — Redéployer (indispensable)

**Deployments** → **Retry deployment** sur le dernier déploiement.
Sans cette étape, la liaison ne s'applique pas et rien ne s'enregistre.

---

## Étape 4 — Vérifier

**Le test des bilans :** ouvre ton adresse, connecte-toi avec un code client, dépose un bilan,
recharge la page. S'il est toujours là, c'est bon.

**Le test des candidatures :** ouvre `/methode`, remplis « Candidater » avec un faux prénom et
ton numéro, envoie. Reviens à la racine, connecte-toi avec `BBP-COACH` → onglet **Prospects** :
la candidature doit y être.

**Si ça ne marche pas :** ouvre `ton-site.pages.dev/api/prospects` directement dans le navigateur.
- `{"prospects":[]}` → tout va bien, il n'y a juste rien encore
- `{"error":"Espace KV non lié..."}` → l'étape 2 ou 3 a été manquée
- une page d'erreur 404 → le dossier `functions/` n'a pas été déposé

---

## Étape 5 — Partager

Dans **Réglages**, chaque client a un bouton **« Envoyer son code »** qui ouvre WhatsApp avec
le message prêt. Ajoute ton adresse dedans.

Ton lien de bio Instagram : **`buildbypaul.pages.dev/methode`**

---

## Plus tard

**Mise à jour :** projet → **Create deployment** → glisse le nouveau dossier. Les bilans déjà
déposés ne bougent pas, ils vivent dans le KV.

**Nom de domaine** (~10 €/an) : **Custom domains** → **Set up a domain**.
