// Stockage persistant des bilans et des modifications, dans Cloudflare KV.
// Remplace le stockage fourni par Claude quand le site est hébergé.

const CLES_AUTORISEES = ["bbp-bilans", "bbp-notion-cache", "bbp-edits"];
const PREFIXES_AUTORISES = ["bbp-media-", "bbp-fichier-"]; // galerie : index + fichiers
const TAILLE_MAX = 900_000;      // clés classiques
const TAILLE_MAX_MEDIA = 6_000_000; // fichiers de la galerie (~6 Mo)

const cleValide = (k) =>
  CLES_AUTORISEES.includes(k) || PREFIXES_AUTORISES.some((p) => k.startsWith(p) && k.length < 120);

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });

export async function onRequest({ request, env }) {
  if (!env.BBP) {
    return json({ error: "Espace KV non lié. Crée le namespace et lie-le sous le nom BBP." }, 500);
  }

  const key = new URL(request.url).searchParams.get("key");
  if (!key || !cleValide(key)) {
    return json({ error: "clé non autorisée" }, 400);
  }

  if (request.method === "GET") {
    const value = await env.BBP.get(key);
    return json({ key, value });
  }

  if (request.method === "DELETE") {
    await env.BBP.delete(key);
    return json({ key, ok: true });
  }

  if (request.method === "PUT" || request.method === "POST") {
    let body;
    try {
      body = await request.json();
    } catch {
      return json({ error: "corps invalide" }, 400);
    }
    const value = typeof body.value === "string" ? body.value : JSON.stringify(body.value ?? null);
    const plafond = key.startsWith("bbp-fichier-") ? TAILLE_MAX_MEDIA : TAILLE_MAX;
    if (value.length > plafond) return json({ error: "données trop volumineuses" }, 413);

    await env.BBP.put(key, value);
    return json({ key, ok: true });
  }

  return json({ error: "méthode non autorisée" }, 405);
}
